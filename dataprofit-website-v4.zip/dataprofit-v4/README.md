# DataProfit V4 — Light analytics portfolio

Open index.html in a browser after extracting the ZIP. No build step or external dependencies. For deployment, upload this folder to a static host. The standalone preview embeds all pages, styles, scripts and the favicon.

Nine interactive demo dashboards, with monthly period and segment filters, KPI cards, charts, breakdowns and CSV downloads. All data is deterministic and synthetic. Runtime fields in exported CSVs are minutes. The contact form still prepares a mailto draft, not a server submission. About page uses selected resume facts without employer names, personal phone numbers or personal email.

Light colour scheme is explicitly declared; browser extensions that forcibly recolour pages may override it. No live integrations, no real client data or measured client results. English only.
